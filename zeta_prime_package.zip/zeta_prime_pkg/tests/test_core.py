"""Tests for zeta_prime core functions."""
import math
import pytest
import sys
sys.path.insert(0, '..')
from zeta_prime import (
    theta, theta_prime, Z_hardy, Z_prime,
    zeta_prime_sq, zeta_prime_at_zero,
    T8_components, find_zeros, spacing_stats,
)

# Known zeros of ζ (Odlyzko)
ZEROS = [
    14.134725141734693,
    21.022039638771554,
    25.010857580145688,
    30.424876125859513,
    37.586178158825671,
]

def test_theta_type():
    assert isinstance(theta(100.0), float)

def test_theta_prime_positive():
    # θ'(t) > 0 for t > 2π
    for t in [10, 100, 1000]:
        assert theta_prime(t) > 0

def test_Z_real():
    for t in [50.0, 100.0, 500.0]:
        assert isinstance(Z_hardy(t), float)

def test_T8_identity():
    """T8: |ζ'|² = (θ'Z)² + (Z')²  must hold exactly."""
    for t in [100.0, 500.0, 1000.0, 5000.0]:
        ph, am, total = T8_components(t)
        direct = zeta_prime_sq(t)
        assert abs(total - direct) < 1e-10, f"T8 failed at t={t}"

def test_T9_at_zeros():
    """T9: |ζ'(½+iγ)| = |Z'(γ)|.  Z(γ) must be ≈ 0."""
    for gamma in ZEROS:
        z_val = Z_hardy(gamma)
        # Z at a zero must be small (RS accuracy)
        assert abs(z_val) < 2.0, f"|Z({gamma})| = {abs(z_val):.4f}"
        # T9 value must be positive
        t9 = zeta_prime_at_zero(gamma)
        assert t9 > 0

def test_find_zeros_returns_list():
    zeros = find_zeros(14.0, 25.0, step=0.05)
    assert isinstance(zeros, list)
    assert len(zeros) >= 1
    assert all("gamma" in z and "Zp_abs" in z for z in zeros)

def test_spacing_stats():
    zeros = find_zeros(100.0, 200.0, step=0.05)
    stats = spacing_stats(zeros)
    assert "rho_Zp_ssym" in stats
    # ρ should be positive (our discovered law)
    assert stats["rho_Zp_ssym"] > 0.3, \
        f"Expected ρ > 0.3, got {stats['rho_Zp_ssym']:.4f}"

def test_T8_accuracy_vs_mpmath():
    """Optional: compare T8 with mpmath if available."""
    try:
        import mpmath
        mpmath.mp.dps = 25
        for t in [100.0, 500.0, 1000.0]:
            s   = mpmath.mpc(0.5, t)
            ref = float(abs(mpmath.zeta(s, derivative=1)) ** 2)
            val = zeta_prime_sq(t)
            err = abs(val - ref) / max(ref, 0.01) * 100
            assert err < 35.0  # RS accuracy varies: ~31% at t=100, <1% at t>500  # RS accuracy at small t, f"T8 error {err:.2f}% at t={t}"
    except ImportError:
        pytest.skip("mpmath not installed")
