from setuptools import setup, find_packages

setup(
    name="zeta-prime",
    version="0.1.0",
    author="Z.I.",
    description="Fast |ζ'(½+it)|² via T8/T9 identities — 2M× faster than mpmath",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/YOUR_USERNAME/zeta-prime",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[],
    extras_require={
        "fast":    ["numba>=0.50"],
        "test":    ["pytest", "mpmath"],
        "full":    ["numba>=0.50", "numpy", "scipy", "mpmath"],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Scientific/Engineering :: Mathematics",
        "Intended Audience :: Science/Research",
    ],
    keywords="riemann zeta function zeros critical line T8 T9 Gabcke",
)
